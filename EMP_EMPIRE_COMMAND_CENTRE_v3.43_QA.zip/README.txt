EMP EMPIRE COMMAND CENTRE — v3.41 QA

Change in this build: extracted full-backup schema validation into empValidateBackupPayload and added a repeatable Node.js regression suite that exercises the actual validator from index.html. Tests cover valid partial backups, explicit null clears, empty/unsupported backups, unknown keys, malformed roster/material rows, invalid quantities, oversized lists, and invalid checklist entries. Run with: node tests/backup-validation.test.js.

Change in this build: adds a repeatable Node.js CSV parser regression test harness. It tests UTF-8 BOM handling, quoted commas, escaped quotes, multiline quoted cells, CRLF rows, malformed quotes, and unexpected text after closing quotes against the parser extracted from index.html. Run with: node tests/csv-parser.test.js. This is an automated parser regression suite, not a browser interaction test.

EMP EMPIRE COMMAND CENTRE — v3.39 QA

Change in this build: Player Intelligence CSV import now rejects missing Name/Player headers, duplicate or conflicting normalized headings, and data rows with more cells than the header. This prevents ambiguous column mapping and obvious row-shift errors before any roster changes are made.

Change in this build: full backup restore now verifies every localStorage write/removal by reading it back. If verification fails, it attempts to roll back the affected keys and reports keys whose rollback could not be verified.

EMP EMPIRE COMMAND CENTRE — v3.36 QA

Change in this build: Warplane and Titan material delete/clear actions now roll back the visible list when browser storage fails. A failed remove restores the row, and a failed clear restores the prior rows, with an explicit warning to export CSV before retrying.

EMP EMPIRE COMMAND CENTRE — v3.34 QA

Change in this build: the troop formation calculator now invalidates its copyable report whenever a troop row is edited/removed or the formation name/available capacity changes. Users must recalculate before copying, preventing stale formations from being shared as current.


Change in this build: Warplane and Titan material forms now keep entered values when browser storage fails, while leaving the new row visible for CSV export and showing an explicit warning. The form is cleared only after a confirmed save.


Change in this build: when saved Player Intelligence, Warplane, or Titan data is malformed, add/clear actions are blocked before they alter the in-page list or clear the form. This preserves the recovery path and makes the warning explicit until a valid backup is restored.

Change in this build: Player intelligence comparisons now display missing City Hall, battle power, or officer power as “Unknown” and suppress the difference unless both players have numeric values. This avoids presenting missing scouting data as zero.

EMP EMPIRE COMMAND CENTRE — BUILD v3.4 (WARPLANE XP INPUT VALIDATION QA)

Contents
- index.html: self-contained static website and calculators
- emp-badge.jpg: original EMP eagle badge

Features in this build
- Advanced material planner rejects invalid or negative entered quantities instead of silently coercing them to zero; blank required values remain explicitly unknown
- Resource budget rejects blank, invalid, and negative inputs instead of silently converting them to zero
- Uranium estimate validates hours (0–24), whole-number days, stored uranium, and mine/level rate before calculating
- Uranium production and potential plunder remain separate figures; invalid submissions do not replace the last valid copy report
- Building calculator with explicit missing-data warnings
- Resource budget and officer planners
- 6-star skill XP calculator (verify current game values)
- General material calculator, troop-capacity calculator, uranium estimate, timer tool and merit-rank bonus calculator
- Dedicated Warplane development lab: cumulative XP tracker, persistent material shopping list, optional cost estimates, CSV export and development checklist
- Local player intelligence roster with CSV/JSON import/export and player comparison
- Expanded local diagnostics: checks both directions of navigation-to-section links and confirms key calculator/backup logic markers are present
- Site-wide JSON backup and restore for saved player roster, Warplane materials/checklist, and Titan materials
- 18 language options; Arabic switches document direction to RTL

Data integrity
This is a community-made, unofficial tool. The level-55 Warplane XP benchmark of 8,535,900 is taken from a community calculator reference and must be checked against the current game. Warplane costs, pack contents/prices, and many building/officer/Titan values remain incomplete or unverified. Unknown values are never treated as zero. Do not use partial data as a complete spending budget.

Backup note
The site-wide JSON backup exports the saved player roster, Warplane material list/checklist, and Titan material list stored by this browser. Empty modules are explicitly marked null. Restore validates the format and data types before changing anything, shows a count preview, asks for confirmation, and attempts rollback if storage writes fail. Keys missing from older backups are left untouched; null values explicitly clear a module. It does not export unsaved form fields or records from other websites. Keep a separate copy of the backup file.

Deployment
Upload index.html and emp-badge.jpg together at the root of the existing Netlify site. Keep a backup of the current site first. This package does not itself publish changes to Netlify.

QA note
The local diagnostics are structural checks only. They do not execute every calculator, verify live game data, or prove the deployed site works in all browsers.

References
https://aoztips.com/calculators/
https://aoztips.com/warplane-equipment/
https://aozcodes.com/troops/warplane/
https://aozstats.com/
https://www.aozresources.com/


Version 1.0 hardening: restore input is validated before changing saved data; if browser storage fails part-way through restore, the code attempts to roll back to the previous saved values. The download URL is kept alive briefly to improve Safari/iPad download reliability. Titan Development Planner with locally saved material rows, shortage calculations, optional user-entered GBP costs and CSV export. It uses only requirements entered by the user; unknown Titan values are not inferred. Officer Merit Rank Calculator remains a community-reference estimate and should be checked against the current game.


Testing notes for v1.0
- JavaScript syntax checked with Node.js.
- Static HTML check: no duplicate IDs; every getElementById reference and label target exists; all nine navigation tabs have matching sections.
- ZIP archive integrity checked after packaging.
- Full interactive browser testing could not be completed in the current build environment, so this is not represented as a fully browser-certified release.

Version 1.1 local diagnostics
- Adds a Data & Sources panel to check navigation-to-section matching, duplicate element IDs, the badge element, core control presence, and localStorage read/write/remove support.
- Diagnostics can be exported as a plain-text report. They are structural/browser checks, not proof of every calculation's correctness or of live Netlify deployment.

Version 1.2 notes
- Safer backup format with explicit empty-module markers.
- Restore preview includes player/material/checklist counts.
- Older backups that omit keys no longer clear unrelated local data.
- File-size and list-size guards reduce accidental import of unsuitable files.

Version 1.3 notes
- Player CSV/JSON import is now non-destructive: confirm to append records; cancel aborts without changing the roster.
- Import no longer interprets Cancel as a command to replace the entire roster.

Version 1.4 notes
- Player CSV/JSON import now rejects files larger than 5 MB and lists above 10,000 rows before changing the roster. This reduces accidental oversized imports and keeps import behavior predictable.

Version 1.5 notes
- Player CSV import now handles UTF-8 byte-order marks, quoted commas, escaped quotes, and multi-line quoted fields.
- Malformed CSV quoting is rejected with an explanatory error instead of risking incorrect column alignment.
- Automated parser checks passed for basic rows, quoted commas, escaped quotes, multi-line fields, UTF-8 BOM, and malformed quote rejection.

Version 1.6 notes
- CSV exports now neutralise spreadsheet-formula-like text cells (for example values beginning with =, +, or @, including after whitespace) to reduce formula-injection risk when opening a roster export in spreadsheet software.
- CSV export checks passed for ordinary text, formula-like text, and embedded quotation marks.

Unreleased data update (next package)
- Added the user-supplied Main Hall/City Hall upgrade costs for levels 31–41 to the building calculator.
- These rows are attributed to the supplied screenshot and still carry an in-game verification warning. Level 37 Uranium is lower than level 36 in the screenshot; it has been preserved as shown, not silently corrected.
- Other buildings and Main Hall levels below 31 remain incomplete; the calculator should continue to flag missing steps.

Officer Equipment reference
The Officer Equipment section includes a searchable transcription of the user-provided Officer Equipment v3.1 image dated 27 January 2025. It is an effect-label reference only, not an equipment cost database. Some tiny image text is difficult to read; verify any tactical decision against the current game. Do not treat paraphrased labels as exact formulas.


Update note: the City Hall/Main Hall cost table now includes the user-supplied levels 1–30 screenshot values alongside levels 31–41. Costs are labelled as user-supplied and must be checked in-game. Other building rows remain partial; missing levels are never treated as zero.

Version 2.0 working update
- Main Hall/City Hall upgrade plans now show the prerequisite building requirements transcribed from the supplied level 1–41 reference image, alongside costs where available.
- Requirements are included in the generated copyable plan. Requirements not shown in the supplied image are labelled as not listed rather than guessed.
- This is a transcription aid; check the live in-game requirement before spending resources.


QA pass — 10 October 2026
- JavaScript syntax check passed after the latest safety patch.
- Static audit found all getElementById references map to existing HTML IDs.
- Static audit confirmed 9 navigation tabs and 9 matching sections.
- Troop-type input now HTML-escapes imported/default text before inserting it into the page.
- Full real-browser interaction testing is still required; this package must not be described as fully browser-certified.


V2.4 QA update: Building calculator now flags missing/invalid resource fields within a present level row instead of silently treating absent values as zero. Such fields display UNKNOWN and are excluded from the numeric subtotal; incomplete totals are explicitly warned.


Version 2.5 QA changes
- Full backup restore now validates saved Warplane and Titan required quantities, owned quantities and optional unit costs as blank or non-negative numeric values before prompting to restore. This blocks malformed or negative numeric entries from being restored into the material planners.
- Verification performed for this package: Node.js syntax check; HTML ID/reference/tab audit; backup validation guard review; ZIP integrity check. Full browser interaction testing is still outstanding, and game-data coverage remains incomplete.


V2.7 QA CHANGE (2026-10-10)
Troop capacity calculator now rejects blank, negative, non-finite, or fractional troop quantities and invalid available capacity before calculating. Capacity-per-troop must be a non-negative number. This is a code-level validation fix; verify the interactive page on the deployed website.

Version 2.8 input-validation update
Resource budget now refuses blank, non-numeric, non-finite, or negative required/owned values and shows a warning. Uranium planner refuses invalid hours, fractional/negative days, and blank/negative/invalid stored stock. Syntax and package integrity checks are included in this QA pass; a live browser/device test is still required on the deployed website.


Version 2.9 QA update — 10 October 2026
- Officer 6-Star Skill XP planner now rejects blank, non-numeric, fractional or out-of-range levels, target levels below current, negative/invalid owned XP and book XP, and conversion values outside 0–100%. It shows a warning and clears the stale copy report rather than silently clamping bad values.
- Checks: JavaScript syntax; duplicate HTML IDs; literal getElementById references; 9 navigation tabs and 9 sections; ZIP integrity. Full browser/device interaction test is still required on the deployed website.


Version 3.0 QA update — Merit calculator input validation
- Merit rank selection is validated before calculation. Base attack, base HP and fleet capacity must be present, finite and non-negative; invalid inputs show a warning and clear the stale copy report.
- Verification: JavaScript syntax, HTML ID uniqueness and references, navigation-to-section matching, required asset presence, and ZIP integrity. This is a code-level QA build, not a live-browser certification.


Version 3.4 QA update — 10 October 2026
- Timer calculator rejects blank, negative, non-numeric and fractional values rather than silently converting them to zero.
- Timer hours must be 0–23 and timer minutes 0–59; speed-up day/hour/minute fields accept whole non-negative values.
- Invalid submissions show a warning and do not produce a result.
- QA scope: JavaScript syntax, HTML ID uniqueness, timer-handler validation cases, and ZIP integrity. This is not a full live-browser certification.


Version 3.4 QA update — 10 October 2026
- Warplane XP planner now rejects blank, fractional, non-numeric, or out-of-range current/target levels rather than flooring/clamping them silently. Levels must be whole numbers from 1 to 55, and target level cannot be below current level.
- Target cumulative XP is required and must be non-negative; current cumulative XP may be blank for benchmark-only view, or a non-negative number. Invalid submissions clear the prior copyable result.
- Code/package QA only; a complete live-browser test has not been performed.

Version 3.7 QA update — backup restore validation
- Restore now rejects an otherwise well-formed backup whose data object is empty, instead of prompting for a no-op restore and reloading the page.
- Warplane checklist restore rejects objects containing more than 10,000 checklist items, matching the defensive row limits used by the other saved-data lists.
- Existing behavior retained: unknown keys and malformed record/quantity types are rejected before saved data is changed; restore asks for confirmation and attempts rollback if storage writes fail.
- QA scope: JavaScript syntax, duplicate HTML ID audit, literal element-reference audit, navigation/section mapping, backup guard checks and ZIP integrity. Full live-browser testing remains outstanding.

Version 3.8 QA update — player roster import validation (10 October 2026)
- CSV/JSON roster imports now reject non-blank Battle Power or Officer Power values that are non-numeric or negative. Leave a value blank when the scouting figure is unknown.
- Extremely long imported field values (over 2,000 characters) are rejected before any records are appended. Existing roster records are retained if validation fails.
- QA scope: JavaScript syntax check, duplicate HTML ID check, source guard checks and ZIP integrity. A complete live-browser/device test remains outstanding.


Version 3.9 QA update — language preference persistence (10 October 2026)
- The selected interface language is saved locally in this browser and restored on the next visit when browser storage is available.
- Only recognized language codes are restored; invalid or unavailable saved values fall back to English.
- If local storage is blocked, the interface still applies the chosen language for the current page session.
- QA scope: JavaScript syntax, 18 language option/source checks, selection persistence guard checks, duplicate ID/reference checks and ZIP integrity. Full live-browser testing remains outstanding.


Version 3.10 QA update — Player Intelligence summary accuracy (10 October 2026)
- Average City Hall now averages only valid, recorded City Hall levels; unknown values no longer lower the average as if they were C0. If none are recorded, it displays Unknown.
- Missing or invalid Battle Power and Officer Power now display as Unknown in the roster rather than as zero. Combined BP sums valid recorded values only and displays Unknown if none are available.
- QA scope: JavaScript syntax, direct helper tests for empty/mixed/invalid values, HTML ID/reference audit, and ZIP integrity. Full live-browser testing remains outstanding.


Version 3.11 QA update — full-backup roster validation (10 October 2026)
When restoring a full EMP backup, player roster entries now receive the same Battle Power and Officer Power validation as CSV/JSON imports. Blank metrics remain allowed for unknown scouting values; entered metrics must be finite, non-negative numbers. Oversized roster text fields (over 2,000 characters) are rejected before any saved data is changed. This is a code-level validation update; test restore/rollback on the target live site before relying on it for important data.


Version 3.13 QA update — saved-data integrity warnings (10 October 2026)
On startup, malformed or wrong-shaped Player Intelligence, Warplane material, and Titan material storage is no longer silently treated as a clean empty list. The original stored value is left untouched, and a warning is surfaced in Player Intelligence status and in the local diagnostics report. This helps prevent users from unknowingly overwriting unreadable local data. If a module reports a warning, export/recover a backup before editing or adding records. Code-level QA only; full live-browser testing remains outstanding.


Version 3.13 QA update
- Protects existing Player Intelligence, Warplane materials, Titan materials and Warplane checklist storage when saved data is malformed.
- Blocks writes to a module whose saved value could not be read or validated, preventing a new empty list from overwriting the original stored value.
- Shows a recovery warning and directs the user to restore a valid backup first.
- This is code-level QA; live-browser testing and deployment are not included.


Version 3.15 QA — saved roster integrity
- Startup now validates every saved Player Intelligence row before filtering or rendering.
- Malformed rows, missing player names, and oversized roster fields trigger the existing corruption guard.
- Saving is blocked so a later edit cannot silently overwrite the original browser-stored roster.
- Existing storage values are not modified by this validation check.


v3.15 QA note: invalid resource-budget submissions now clear the previous copyable budget report, preventing an old result from being copied after a failed calculation.


Version 3.16 QA — clipboard reliability (10 October 2026)
Copy actions now confirm success only when the browser reports a successful clipboard write. If the modern Clipboard API fails, the page tries the legacy copy command; if that also fails, it offers the report text for manual copying instead of claiming it was copied.


Version 3.17 QA — backup field-size validation
Full-backup restore now rejects Warplane and Titan material records whose name, required, owned, or cost fields exceed 2,000 characters. This complements existing row-count and numeric validation, reducing the chance that malformed oversized fields enter saved data. No existing records are changed when validation rejects a backup.


v3.18 QA update: the local diagnostics storage probe now preserves and restores any pre-existing value under its temporary test key instead of unconditionally deleting it. If cleanup fails, diagnostics reports a CHECK rather than claiming storage passed.


v3.19 QA update: Warplane material storage now clears its persistent save-warning flag after a later successful save, and reports success/failure explicitly. This prevents a recovered browser-storage write from leaving a stale warning on the page.


v3.21 QA update — Player Intelligence save-failure safety
- Player Intelligence now checks whether localStorage writes actually succeed. If a roster add/edit cannot be saved, the page keeps the entered form available and restores the in-memory roster to its prior state rather than clearing the form or showing unsaved changes as though they were saved.
- If a delete cannot be saved, the removed player is restored in the visible roster. The status message explicitly warns that changes were not saved and recommends exporting JSON/CSV before leaving or refreshing.
- QA scope: JavaScript syntax, duplicate HTML ID check, roster persistence-path source checks, and ZIP integrity. Live-browser interaction testing remains outstanding.


Version 3.23 QA: full-backup restore now snapshots and rolls back only the data modules actually present in the selected backup. This avoids rewriting unrelated saved modules when restoring an older or partial backup, and limits rollback work to keys that the restore could change.


Version 3.24 QA changes
- Invalid building-upgrade ranges now clear the previous copyable report, preventing a stale plan from being copied after a failed calculation.
- Invalid uranium-planner inputs now clear the previous copyable estimate for the same reason.
- This is a code-level QA change; live-browser testing and deployment have not been performed here.


Version 3.25 QA: Warplane XP planner now rejects current cumulative XP greater than target cumulative XP and clears any stale copyable result instead of displaying zero remaining XP.


v3.26 QA update — troop formation report freshness
- Editing or removing any troop row clears the previous copyable formation report and prompts the user to recalculate.
- Changing formation name or available march capacity also invalidates the old report.
- QA scope: JavaScript syntax, duplicate HTML IDs, ZIP integrity and source guard checks. Full browser interaction testing remains outstanding.


Version 3.27 QA update — Timer calculator hardening (10 October 2026)
- Timer results are visibly invalidated when any timer or speed-up input changes, preventing an old result from looking current.
- Extremely large values that exceed JavaScript safe-integer precision are rejected rather than displayed as potentially misleading time totals.
- Validation is code-level only; live-browser testing and deployment have not been performed here.


Version 3.28 QA update — Merit calculator report freshness
- Changing merit rank, base attack, base HP or fleet capacity clears the previous copyable report and prompts recalculation.
- Merit inputs beyond JavaScript's safe numeric range, or fleet totals that would exceed safe integer precision, are rejected.
- QA scope: JavaScript syntax, duplicate HTML IDs, ZIP integrity and targeted source checks. Full browser interaction testing remains outstanding.


v3.29 QA update — Uranium and 6-star Skill XP report freshness
- Editing uranium mine/level, hours per day, days, or stored uranium invalidates the previous copyable estimate and asks for recalculation.
- Editing current/target skill level, owned XP, book XP, or conversion percentage invalidates the previous copyable skill XP plan.
- This prevents an old estimate from being copied after the user changes inputs. JavaScript syntax and package integrity checks are code-level only; full live-browser testing remains outstanding.


Version 3.30 QA update — numeric overflow protection (10 October 2026)
- Warplane and Titan material cost displays now explicitly flag row or aggregate costs that exceed JavaScript numeric range, instead of formatting Infinity as a currency value. Review unusually large quantities and unit costs before relying on estimates.


Change in this build: CSV exports for Player Intelligence, Warplane, and Titan now include a UTF-8 byte-order mark to improve compatibility with spreadsheet applications when opening Scottish, Arabic, Asian, and other non-ASCII player names and notes. Existing CSV formula-injection protection is retained.

Change in this build: full-backup restore now rejects unknown Warplane checklist item keys, as well as non-boolean values, before writing any saved data.


Version 3.33 QA update — clearer restore preview
- The restore confirmation now distinguishes modules that will be cleared (explicit null), modules that will be restored, and modules absent from a partial backup that will be left unchanged. This avoids showing a misleading zero-row count for modules that are not included.
- Code-level checks only; live-browser restore testing remains outstanding.


Version 3.34 QA update — Player Intelligence import save-state accuracy
- CSV/JSON import now stops before changing the roster if startup detected that the existing saved roster is malformed or unreadable.
- After a valid import, the interface only says the records are saved when the browser storage write succeeds. If storage fails, it clearly says the imported rows are visible but unsaved and recommends exporting immediately.
- Code-level QA: JavaScript syntax, duplicate HTML IDs, import guard/status source checks, and ZIP integrity. Full live-browser interaction testing remains outstanding.


Version 3.37 QA update — CSV header compatibility
- Player Intelligence CSV imports now normalize spaces, underscores, and hyphens in column headings and recognize common aliases such as Player, Tag, City Hall, Battle Power, Officer Power, Warplane, and Scouted Date.
- This improves imports from spreadsheets that use descriptive headings rather than the website's compact field names. Existing row validation and append-only import behavior remain in place.
- QA scope: JavaScript syntax, targeted header-normalization checks, HTML ID audit, and ZIP integrity. Live-browser import testing remains outstanding.


Version 3.41 QA update — storage restore rollback regression tests (10 October 2026)
- Extracted the site’s actual empRestoreStorageWithRollback helper into a directly testable function, then added automated tests using simulated browser storage.
- Tests cover verified multi-module writes, partial backups leaving unrelated keys untouched, rollback after a later write fails, rollback after a clear/removal, and explicit reporting when rollback itself fails.
- Run with: node tests/storage-rollback.test.js
- QA results: CSV parser 10/10; backup validation 12/12; storage rollback 6/6. JavaScript syntax passed; 152 HTML IDs checked with no duplicates; ZIP integrity checked. Live-browser testing and deployment remain outstanding.


Version 3.42 QA update — calculator regression checks (10 October 2026)
- Added tests/calculator-regression.test.js to check shipped calculator validation and report invalidation markers, plus boundary arithmetic for timer totals, formation capacity, and book rounding.
- The suite performs source-level checks against index.html and arithmetic boundary tests; it is not a full DOM/browser simulation.
- Run with: node tests/calculator-regression.test.js
- QA scope: calculator regression checks, existing CSV parser, backup validation, and simulated storage rollback suites; JavaScript syntax, HTML ID audit, and ZIP integrity. Live-browser testing and deployment remain outstanding.


Version 3.43 QA update — test package layout fix (10 October 2026)
- Moved the four automated regression suites into the documented tests/ directory so their relative path to ../index.html works when the ZIP is extracted.
- Verified all four suites from the extracted package: CSV parser 10/10, backup validation 12/12, storage rollback 6/6, calculator regression 9/9 (37 total).
- Extracted inline JavaScript passes node --check. Static HTML ID audit found 149 IDs with no duplicates; script-generated IDs are excluded from that static count.
- ZIP integrity checked. Live-browser testing and deployment remain outstanding.
