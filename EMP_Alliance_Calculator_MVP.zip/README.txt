EMP Alliance Calculator — MVP website
====================================

Branding
--------
EMP Alliance Calculator with the Scottish Saltire only. No Union Jack.

What works in this MVP
----------------------
- Mobile-friendly website layout.
- Language selector for English, Arabic, Dutch, French, German, Indonesian, Italian,
  Japanese, Korean, Portuguese, Russian, Simplified Chinese, Spanish, Thai,
  Traditional Chinese, Vietnamese, Greek and Scottish Gaelic.
- Arabic uses right-to-left page direction.
- Working general quantity/level difference calculator.
- Working pack budget calculator based on user-entered pack contents and price.
- Local planning notes with copy action.
- Links to the original game-specific community calculators.

Important accuracy limit
------------------------
This is a first working MVP, not yet the full set of game-specific calculators.
The game-specific cards are references for now. The general calculators use values
you type in; they do not invent AoZ upgrade requirements. Only English, Spanish,
Portuguese, French, German, Russian, Korean and Greek have broader UI translations
at this stage; remaining language options currently fall back to English for any
strings that have not yet been translated. These translations need review by native
speakers before being treated as final.

Preview
-------
Open index.html in a browser.

Free publishing via GitHub Pages
--------------------------------
1. Create/sign in to GitHub.
2. Create a public repository named emp-alliance-calculator.
3. Upload index.html to the repository root.
4. Open Settings -> Pages.
5. Select Deploy from a branch, choose main and /(root), then Save.
6. GitHub will provide a URL. Share that URL with EMP members.

Alternative: Netlify
--------------------
Sign in to Netlify and use manual deploy to upload index.html. Share the URL it provides.

The first hosting step does not require a custom domain or member accounts.
