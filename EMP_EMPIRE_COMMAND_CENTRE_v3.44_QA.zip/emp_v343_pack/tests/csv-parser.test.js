// EMP EMPIRE CSV parser regression tests (Node.js built-ins only).
// Extracts and executes the actual parseCsv function from ../index.html.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const parserLine = html.split(/\r?\n/).find(line => line.startsWith('function parseCsv(text)'));
assert.ok(parserLine, 'parseCsv(text) must exist in index.html');
const sandbox = {};
vm.runInNewContext(parserLine + '\nthis.parseCsv = parseCsv;', sandbox);
const parseCsv = input => Array.from(sandbox.parseCsv(input), row => Array.from(row));
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

test('basic comma-separated rows', () => {
  assert.deepEqual(parseCsv('Name,Alliance\nJia,EMP'), [['Name','Alliance'],['Jia','EMP']]);
});
test('UTF-8 BOM stripped from first header', () => {
  assert.deepEqual(parseCsv('\uFEFFName,BP\r\nJia,123'), [['Name','BP'],['Jia','123']]);
});
test('quoted commas stay inside one cell', () => {
  assert.deepEqual(parseCsv('Name,Notes\r\nJia,"likes commas, here"'), [['Name','Notes'],['Jia','likes commas, here']]);
});
test('escaped quotes are unescaped', () => {
  assert.deepEqual(parseCsv('Name,Notes\nJia,"said ""hello"""'), [['Name','Notes'],['Jia','said "hello"']]);
});
test('multiline quoted cells are preserved', () => {
  assert.deepEqual(parseCsv('Name,Notes\r\nJia,"line one\r\nline two"'), [['Name','Notes'],['Jia','line one\r\nline two']]);
});
test('CRLF line endings are parsed', () => {
  assert.deepEqual(parseCsv('Name\r\nJia\r\nMon'), [['Name'],['Jia'],['Mon']]);
});
test('empty trailing rows are ignored', () => {
  assert.deepEqual(parseCsv('Name,BP\nJia,12\n\n'), [['Name','BP'],['Jia','12']]);
});
test('unclosed quoted field is rejected', () => {
  assert.throws(() => parseCsv('Name,Notes\nJia,"unfinished'), /never closed/);
});
test('quote in middle of unquoted field is rejected', () => {
  assert.throws(() => parseCsv('Name,Notes\nJia,ab"cd'), /middle of an unquoted field/);
});
test('text after closing quote is rejected', () => {
  assert.throws(() => parseCsv('Name,Notes\nJia,"ok"oops'), /unexpected text after a closing quote/);
});
console.log(`\n${passed} CSV parser regression tests passed.`);
