// Regression tests for the exact empRestoreStorageWithRollback helper used by index.html.
// Node.js built-ins only; no browser or external packages required.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const match = html.match(/function empRestoreStorageWithRollback\(restoreData,storage\)\s*\{[\s\S]*?\n\}/);
assert.ok(match, 'empRestoreStorageWithRollback must exist in index.html');
const sandbox = {};
vm.runInNewContext(match[0] + '\nthis.restore = empRestoreStorageWithRollback;', sandbox);
const restore = (data, storage) => sandbox.restore(data, storage);
function memoryStorage(initial = {}, failAt = null) {
  const map = new Map(Object.entries(initial)); let writes = 0;
  return {
    map,
    getItem(k) { return map.has(k) ? map.get(k) : null; },
    setItem(k, v) { writes++; if (failAt && failAt(k, String(v), writes)) throw new Error('simulated storage write failure'); map.set(k, String(v)); },
    removeItem(k) { map.delete(k); },
  };
}
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

test('writes and verifies multiple modules', () => {
  const s = memoryStorage({ a: 'old-a', b: 'old-b' });
  assert.equal(restore({ a: [{ name: 'Jia' }], b: null }, s), true);
  assert.equal(s.getItem('a'), '[{"name":"Jia"}]'); assert.equal(s.getItem('b'), null);
});
test('leaves keys absent from partial backup untouched', () => {
  const s = memoryStorage({ a: 'old-a', unrelated: 'keep' });
  restore({ a: ['new'] }, s);
  assert.equal(s.getItem('unrelated'), 'keep');
});
test('rolls back earlier successful writes after a later write fails', () => {
  let failed = false;
  const s = memoryStorage({ a: 'old-a', b: 'old-b' }, (k, v) => { if (k === 'b' && v === '["new-b"]' && !failed) { failed = true; return true; } return false; });
  assert.throws(() => restore({ a: ['new-a'], b: ['new-b'] }, s), /rolled back where possible/);
  assert.equal(s.getItem('a'), 'old-a'); assert.equal(s.getItem('b'), 'old-b');
});
test('rolls back removal when a later write fails', () => {
  let failed = false;
  const s = memoryStorage({ a: 'old-a', b: 'old-b' }, (k, v) => { if (k === 'b' && v === '["new-b"]' && !failed) { failed = true; return true; } return false; });
  assert.throws(() => restore({ a: null, b: ['new-b'] }, s), /rolled back where possible/);
  assert.equal(s.getItem('a'), 'old-a'); assert.equal(s.getItem('b'), 'old-b');
});
test('reports keys whose rollback itself fails', () => {
  let failedForward = false, failedRollback = false;
  const s = memoryStorage({ a: 'old-a', b: 'old-b' }, (k, v) => {
    if (k === 'b' && v === '["new-b"]' && !failedForward) { failedForward = true; return true; }
    if (k === 'a' && v === 'old-a' && !failedRollback) { failedRollback = true; return true; }
    return false;
  });
  assert.throws(() => restore({ a: ['new-a'], b: ['new-b'] }, s), /Rollback could not be verified for: a/);
});
test('verifies a removed key is truly absent', () => {
  const s = memoryStorage({ a: 'old-a' });
  assert.equal(restore({ a: null }, s), true); assert.equal(s.getItem('a'), null);
});
console.log(`\n${passed} storage rollback regression tests passed.`);
