// Calculator regression checks for EMP EMPIRE Command Centre.
// Checks the shipped source for input invalidation/validation guards, then tests
// boundary arithmetic used by the calculator formulas. Node.js built-ins only.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }
function section(start, end) {
  const a = html.indexOf(start);
  assert.notEqual(a, -1, `source marker missing: ${start}`);
  const b = html.indexOf(end, a + start.length);
  assert.notEqual(b, -1, `end marker missing: ${end}`);
  return html.slice(a, b);
}

test('troop formation clears the previous report when troop inputs change', () => {
  const src = section("const troopRows=", "function timeVal(");
  assert.match(src, /addEventListener\('input',[\s\S]*?lastTroops=''/);
  assert.match(src, /remove-row[\s\S]*?lastTroops=''/);
  assert.match(src, /Number\.isInteger\(Number\(r\.countText\)\)/);
  assert.match(src, /Number\.isFinite\(Number\(availableText\)\)/);
});

test('timer rejects invalid whole-number fields and unsafe totals', () => {
  const src = section("document.getElementById('calcTimer').onclick", "].forEach(id=>document.getElementById(id).addEventListener('input'");
  assert.match(src, /!Number\.isInteger\(vals\[id\]\)/);
  assert.match(src, /!Number\.isSafeInteger\(before\)/);
});

test('officer skill XP checks level bounds and conversion percentage', () => {
  const src = section("document.getElementById('calcSkillXp').onclick", "document.getElementById('calcWpXp').onclick");
  assert.match(src, /cur<1\|\|cur>30/);
  assert.match(src, /conversion<0\|\|conversion>100/);
  assert.match(src, /lastSkillXp=''/);
});

test('Warplane XP refuses target below current and invalid cumulative XP', () => {
  const src = section("document.getElementById('calcWpXp').onclick", "// Merit report freshness");
  assert.match(src, /targetLevel<curLevel/);
  assert.match(src, /cur>target/);
  assert.match(src, /lastWpXp=''/);
});

test('merit calculator invalidates report after every relevant input changes', () => {
  const src = section("document.getElementById('calcMerit').onclick", "// Titan planner");
  assert.match(src, /addEventListener\('input'/);
  assert.match(src, /lastMerit=''/);
});

test('timer arithmetic never returns negative remaining time', () => {
  const before = 2 * 86400 + 3 * 3600 + 15 * 60;
  const boosts = 4 * 86400;
  const remaining = Math.max(0, before - boosts);
  const unused = Math.max(0, boosts - before);
  assert.equal(remaining, 0);
  assert.equal(unused, boosts - before);
});

test('formation capacity uses troop quantity multiplied by per-troop capacity', () => {
  const rows = [{count: 10, cap: 2.5}, {count: 4, cap: 3}];
  const used = rows.reduce((sum, row) => sum + row.count * row.cap, 0);
  assert.equal(used, 37);
  assert.equal(50 - used, 13);
});

test('skill XP book estimate rounds up partial books', () => {
  const remaining = 101, skillPerBook = 50;
  assert.equal(Math.ceil(remaining / skillPerBook), 3);
  assert.equal(Math.ceil(100 / skillPerBook), 2);
});

test('unsafe timer totals are detected rather than formatted as valid time', () => {
  const hugeDays = Number.MAX_SAFE_INTEGER;
  const seconds = hugeDays * 86400;
  assert.equal(Number.isSafeInteger(seconds), false);
});

console.log(`\n${passed} calculator regression checks passed.`);
