// Tests the actual empValidateBackupPayload function extracted from index.html.
// Node.js built-ins only; no browser or external packages required.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const match = html.match(/function empValidateBackupPayload\(payload\)\s*\{[\s\S]*?\n\}/);
assert.ok(match, 'empValidateBackupPayload must exist in index.html');
const sandbox = {};
vm.runInNewContext(match[0] + '\nthis.validate = empValidateBackupPayload;', sandbox);
const validate = payload => sandbox.validate(payload);
const wrap = data => ({ format: 'EMP-Command-Centre-Backup', version: 1, data });
const roster = [{ name: 'Jia', bp: '123', officer: '' }];
const wp = [{ name: 'Metal', required: 10, owned: 2, unitCost: 1 }];
const titan = [{ name: 'Core', required: '', owned: 0, cost: null }];
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }
function rejects(data, pattern) { assert.throws(() => validate(data), pattern); }

test('accepts valid full backup', () => assert.equal(validate(wrap({ 'emp-command-centre-player-roster-v1': roster, empWarplaneMaterials_v1: wp, empWarplaneChecklist_v1: { '0': true }, empTitanMaterials_v1: titan })), true));
test('accepts a valid partial backup', () => assert.equal(validate(wrap({ 'emp-command-centre-player-roster-v1': roster })), true));
test('accepts explicit null to clear a module', () => assert.equal(validate(wrap({ empTitanMaterials_v1: null })), true));
test('rejects wrong format/version', () => rejects({ format: 'other', version: 1, data: { empTitanMaterials_v1: [] } }, /supported EMP backup/));
test('rejects empty data object', () => rejects(wrap({}), /contains no saved-data modules/));
test('rejects unknown keys', () => rejects(wrap({ unrelated: [] }), /unrecognized data key/));
test('rejects roster record without a name', () => rejects(wrap({ 'emp-command-centre-player-roster-v1': [{ bp: 4 }] }), /invalid record/));
test('rejects negative or nonnumeric Warplane quantity', () => rejects(wrap({ empWarplaneMaterials_v1: [{ name: 'Metal', required: -1, owned: 0, unitCost: 2 }] }), /non-negative numbers/));
test('rejects oversized lists', () => rejects(wrap({ empTitanMaterials_v1: Array.from({ length: 10001 }, (_, i) => ({ name: 'x' + i, required: 0, owned: 0, cost: 0 })) }), /more than 10,000 rows/));
test('rejects unknown checklist item index', () => rejects(wrap({ empWarplaneChecklist_v1: { '8': true } }), /known checklist item numbers/));
test('rejects non-boolean checklist values', () => rejects(wrap({ empWarplaneChecklist_v1: { '0': 'true' } }), /true\/false values/));
test('rejects oversized player field', () => rejects(wrap({ 'emp-command-centre-player-roster-v1': [{ name: 'Jia', notes: 'x'.repeat(2001) }] }), /field longer than 2,000/));
console.log(`\n${passed} backup validation regression tests passed.`);
