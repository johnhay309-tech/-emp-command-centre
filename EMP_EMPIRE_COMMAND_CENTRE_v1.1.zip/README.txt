EMP EMPIRE COMMAND CENTRE — BUILD v1.0

Contents
- index.html: self-contained static website and calculators
- emp-badge.jpg: original EMP eagle badge

Features in this build
- Building calculator with explicit missing-data warnings
- Resource budget and officer planners
- 6-star skill XP calculator (verify current game values)
- General material calculator, troop-capacity calculator, uranium estimate, timer tool and merit-rank bonus calculator
- Dedicated Warplane development lab: cumulative XP tracker, persistent material shopping list, optional cost estimates, CSV export and development checklist
- Local player intelligence roster with CSV/JSON import/export and player comparison
- Site-wide JSON backup and restore for saved player roster, Warplane materials/checklist, and Titan materials
- 18 language options; Arabic switches document direction to RTL

Data integrity
This is a community-made, unofficial tool. The level-55 Warplane XP benchmark of 8,535,900 is taken from a community calculator reference and must be checked against the current game. Warplane costs, pack contents/prices, and many building/officer/Titan values remain incomplete or unverified. Unknown values are never treated as zero. Do not use partial data as a complete spending budget.

Backup note
The site-wide JSON backup exports the saved player roster, Warplane material list/checklist, and Titan material list stored by this browser. It does not export unsaved form fields or records from other websites. Restoring replaces saved data for the included keys on this device. Keep a separate copy of the backup file.

Deployment
Upload index.html and emp-badge.jpg together at the root of the existing Netlify site. Keep a backup of the current site first. This package does not itself publish changes to Netlify.

References
https://aoztips.com/calculators/
https://aoztips.com/warplane-equipment/
https://aozcodes.com/troops/warplane/
https://aozstats.com/
https://www.aozresources.com/


Version 1.0 hardening: restore input is validated before changing saved data; if browser storage fails part-way through restore, the code attempts to roll back to the previous saved values. The download URL is kept alive briefly to improve Safari/iPad download reliability. Titan Development Planner with locally saved material rows, shortage calculations, optional user-entered GBP costs and CSV export. It uses only requirements entered by the user; unknown Titan values are not inferred. Officer Merit Rank Calculator remains a community-reference estimate and should be checked against the current game.


Testing notes for v1.0
- JavaScript syntax checked with Node.js.
- Static HTML check: no duplicate IDs; every getElementById reference and label target exists; all nine navigation tabs have matching sections.
- ZIP archive integrity checked after packaging.
- Full interactive browser testing could not be completed in the current build environment, so this is not represented as a fully browser-certified release.

Version 1.1 local diagnostics
- Adds a Data & Sources panel to check navigation-to-section matching, duplicate element IDs, the badge element, core control presence, and localStorage read/write/remove support.
- Diagnostics can be exported as a plain-text report. They are structural/browser checks, not proof of every calculation's correctness or of live Netlify deployment.
