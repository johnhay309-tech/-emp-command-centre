EMP Alliance Calculator — Tactical Edition

Files:
- index.html: the website
- emp-badge.jpg: cropped image of the official EMP_1 EMPIRE eagle badge supplied by the alliance member

Deploy the contents of this folder to Netlify. Keep index.html and emp-badge.jpg together in the published site root. If Netlify asks for a folder, extract the ZIP first and upload the extracted folder.

This is a visual redesign of the existing MVP, not a complete set of verified Age of Origins game-specific calculators. Check all game-specific figures against current in-game data.
