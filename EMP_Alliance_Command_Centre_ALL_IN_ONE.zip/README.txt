EMP ALLIANCE COMMAND CENTRE — STARTER PACKAGE
================================================
Files:
- index.html : the website, including working budget, manual officer-plan, alliance-report and limited building-cost calculators.
- emp-badge.jpg : place your official EMPIRE badge image here, named exactly emp-badge.jpg.

IMPORTANT DATA LIMITATION
This is a functional starter package, not a complete verified Age of Origins database.
The building calculator only contains a small number of example cost rows from public community references. It explicitly warns when a selected level step has no row. Do not treat partial totals as complete upgrade costs.
The officer planner totals values you enter; it does not claim to know exact officer skill/book costs yet.
Public references used for the initial data and feature scope:
https://aoztips.com/calculators/building/
https://www.aozresources.com/
https://aoztips.com/calculators/
https://aozstats.com/
Verify all costs in game before spending resources. Unofficial fan project; not affiliated with Camel Games or AOZStats.

NETLIFY UPDATE
1. Keep the files index.html and emp-badge.jpg in the same folder.
2. Open your existing Netlify site > Deploys.
3. Upload the extracted folder (or drag its contents into the manual deploy area, depending on what Netlify requests).
4. Confirm the deploy is published, then test your existing .netlify.app link.
Do not upload the ZIP as a nested folder unless Netlify explicitly supports it. Keep the same site to preserve its public URL.
