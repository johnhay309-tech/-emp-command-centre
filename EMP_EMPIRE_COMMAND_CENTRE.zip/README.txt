EMP EMPIRE COMMAND CENTRE — PACKAGE v0.4

Upload the contents of this ZIP (index.html, emp-badge.jpg, README.txt) to the ROOT of your EXISTING Netlify site. Keep index.html and emp-badge.jpg side by side. Do not upload only index.html and do not put the files inside an extra folder.

Included interactive tools:
- Building upgrade calculator with explicit warnings when a level's cost is missing from the limited local sample.
- Resource budget planner (required versus owned).
- Officer material planner (uses user-entered costs; does not fabricate officer curves).
- Generic multi-material upgrade planner for Titan, Warplane, equipment and research.
- Troop capacity / formation calculator with per-troop capacity cost.
- Speed-up and timer calculator.
- Player stat comparison, nation Top-100 merger comparison, and recorded-spending estimator.
- Local player roster with search, sorting, local save, CSV import/export and per-record removal.
- JSON backup/restore of form inputs, 18 language options, Arabic RTL, and the original EMP eagle badge.

Important limits:
- This is an unofficial fan-made tool. It is not affiliated with Camel Games or AOZStats.
- AOZStats is used as a feature reference only. This site does not scrape or access live AOZStats player/nation rankings and does not copy its private code.
- The building-cost table is incomplete. Missing levels are flagged and partial totals must not be used as full upgrade costs.
- Officer, Titan and Warplane-specific requirements must be entered from verified tables/game values. These planners calculate user-entered quantities; they do not invent official upgrade costs.
- Roster and form records are stored locally in the browser where available. Export backups/CSV before clearing browser data or changing devices. There is no cloud sync or user account.
- Language selection changes the language of the supported interface strings. Some detailed tool labels and generated reports may remain in English; check values and labels before relying on a translated report.

Useful references:
https://aozstats.com/
https://aoztips.com/calculators/
https://aoztips.com/calculators/building/
https://www.aozresources.com/

Version 0.4 — EMP roster & analytics update.
