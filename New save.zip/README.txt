EMP EMPIRE COMMAND CENTRE — BUILD v2.8 (INPUT-VALIDATION QA)

Contents
- index.html: self-contained static website and calculators
- emp-badge.jpg: original EMP eagle badge

Features in this build
- Resource budget rejects blank, invalid, and negative inputs instead of silently converting them to zero
- Uranium estimate validates hours (0–24), whole-number days, stored uranium, and mine/level rate before calculating
- Uranium production and potential plunder remain separate figures; invalid submissions do not replace the last valid copy report
- Building calculator with explicit missing-data warnings
- Resource budget and officer planners
- 6-star skill XP calculator (verify current game values)
- General material calculator, troop-capacity calculator, uranium estimate, timer tool and merit-rank bonus calculator
- Dedicated Warplane development lab: cumulative XP tracker, persistent material shopping list, optional cost estimates, CSV export and development checklist
- Local player intelligence roster with CSV/JSON import/export and player comparison
- Expanded local diagnostics: checks both directions of navigation-to-section links and confirms key calculator/backup logic markers are present
- Site-wide JSON backup and restore for saved player roster, Warplane materials/checklist, and Titan materials
- 18 language options; Arabic switches document direction to RTL

Data integrity
This is a community-made, unofficial tool. The level-55 Warplane XP benchmark of 8,535,900 is taken from a community calculator reference and must be checked against the current game. Warplane costs, pack contents/prices, and many building/officer/Titan values remain incomplete or unverified. Unknown values are never treated as zero. Do not use partial data as a complete spending budget.

Backup note
The site-wide JSON backup exports the saved player roster, Warplane material list/checklist, and Titan material list stored by this browser. Empty modules are explicitly marked null. Restore validates the format and data types before changing anything, shows a count preview, asks for confirmation, and attempts rollback if storage writes fail. Keys missing from older backups are left untouched; null values explicitly clear a module. It does not export unsaved form fields or records from other websites. Keep a separate copy of the backup file.

Deployment
Upload index.html and emp-badge.jpg together at the root of the existing Netlify site. Keep a backup of the current site first. This package does not itself publish changes to Netlify.

QA note
The local diagnostics are structural checks only. They do not execute every calculator, verify live game data, or prove the deployed site works in all browsers.

References
https://aoztips.com/calculators/
https://aoztips.com/warplane-equipment/
https://aozcodes.com/troops/warplane/
https://aozstats.com/
https://www.aozresources.com/


Version 1.0 hardening: restore input is validated before changing saved data; if browser storage fails part-way through restore, the code attempts to roll back to the previous saved values. The download URL is kept alive briefly to improve Safari/iPad download reliability. Titan Development Planner with locally saved material rows, shortage calculations, optional user-entered GBP costs and CSV export. It uses only requirements entered by the user; unknown Titan values are not inferred. Officer Merit Rank Calculator remains a community-reference estimate and should be checked against the current game.


Testing notes for v1.0
- JavaScript syntax checked with Node.js.
- Static HTML check: no duplicate IDs; every getElementById reference and label target exists; all nine navigation tabs have matching sections.
- ZIP archive integrity checked after packaging.
- Full interactive browser testing could not be completed in the current build environment, so this is not represented as a fully browser-certified release.

Version 1.1 local diagnostics
- Adds a Data & Sources panel to check navigation-to-section matching, duplicate element IDs, the badge element, core control presence, and localStorage read/write/remove support.
- Diagnostics can be exported as a plain-text report. They are structural/browser checks, not proof of every calculation's correctness or of live Netlify deployment.

Version 1.2 notes
- Safer backup format with explicit empty-module markers.
- Restore preview includes player/material/checklist counts.
- Older backups that omit keys no longer clear unrelated local data.
- File-size and list-size guards reduce accidental import of unsuitable files.

Version 1.3 notes
- Player CSV/JSON import is now non-destructive: confirm to append records; cancel aborts without changing the roster.
- Import no longer interprets Cancel as a command to replace the entire roster.

Version 1.4 notes
- Player CSV/JSON import now rejects files larger than 5 MB and lists above 10,000 rows before changing the roster. This reduces accidental oversized imports and keeps import behavior predictable.

Version 1.5 notes
- Player CSV import now handles UTF-8 byte-order marks, quoted commas, escaped quotes, and multi-line quoted fields.
- Malformed CSV quoting is rejected with an explanatory error instead of risking incorrect column alignment.
- Automated parser checks passed for basic rows, quoted commas, escaped quotes, multi-line fields, UTF-8 BOM, and malformed quote rejection.

Version 1.6 notes
- CSV exports now neutralise spreadsheet-formula-like text cells (for example values beginning with =, +, or @, including after whitespace) to reduce formula-injection risk when opening a roster export in spreadsheet software.
- CSV export checks passed for ordinary text, formula-like text, and embedded quotation marks.

Unreleased data update (next package)
- Added the user-supplied Main Hall/City Hall upgrade costs for levels 31–41 to the building calculator.
- These rows are attributed to the supplied screenshot and still carry an in-game verification warning. Level 37 Uranium is lower than level 36 in the screenshot; it has been preserved as shown, not silently corrected.
- Other buildings and Main Hall levels below 31 remain incomplete; the calculator should continue to flag missing steps.

Officer Equipment reference
The Officer Equipment section includes a searchable transcription of the user-provided Officer Equipment v3.1 image dated 27 January 2025. It is an effect-label reference only, not an equipment cost database. Some tiny image text is difficult to read; verify any tactical decision against the current game. Do not treat paraphrased labels as exact formulas.


Update note: the City Hall/Main Hall cost table now includes the user-supplied levels 1–30 screenshot values alongside levels 31–41. Costs are labelled as user-supplied and must be checked in-game. Other building rows remain partial; missing levels are never treated as zero.

Version 2.0 working update
- Main Hall/City Hall upgrade plans now show the prerequisite building requirements transcribed from the supplied level 1–41 reference image, alongside costs where available.
- Requirements are included in the generated copyable plan. Requirements not shown in the supplied image are labelled as not listed rather than guessed.
- This is a transcription aid; check the live in-game requirement before spending resources.


QA pass — 10 October 2026
- JavaScript syntax check passed after the latest safety patch.
- Static audit found all getElementById references map to existing HTML IDs.
- Static audit confirmed 9 navigation tabs and 9 matching sections.
- Troop-type input now HTML-escapes imported/default text before inserting it into the page.
- Full real-browser interaction testing is still required; this package must not be described as fully browser-certified.


V2.4 QA update: Building calculator now flags missing/invalid resource fields within a present level row instead of silently treating absent values as zero. Such fields display UNKNOWN and are excluded from the numeric subtotal; incomplete totals are explicitly warned.


Version 2.5 QA changes
- Full backup restore now validates saved Warplane and Titan required quantities, owned quantities and optional unit costs as blank or non-negative numeric values before prompting to restore. This blocks malformed or negative numeric entries from being restored into the material planners.
- Verification performed for this package: Node.js syntax check; HTML ID/reference/tab audit; backup validation guard review; ZIP integrity check. Full browser interaction testing is still outstanding, and game-data coverage remains incomplete.


V2.7 QA CHANGE (2026-10-10)
Troop capacity calculator now rejects blank, negative, non-finite, or fractional troop quantities and invalid available capacity before calculating. Capacity-per-troop must be a non-negative number. This is a code-level validation fix; verify the interactive page on the deployed website.

Version 2.8 input-validation update
Resource budget now refuses blank, non-numeric, non-finite, or negative required/owned values and shows a warning. Uranium planner refuses invalid hours, fractional/negative days, and blank/negative/invalid stored stock. Syntax and package integrity checks are included in this QA pass; a live browser/device test is still required on the deployed website.


Version 2.9 QA update — 10 October 2026
- Officer 6-Star Skill XP planner now rejects blank, non-numeric, fractional or out-of-range levels, target levels below current, negative/invalid owned XP and book XP, and conversion values outside 0–100%. It shows a warning and clears the stale copy report rather than silently clamping bad values.
- Checks: JavaScript syntax; duplicate HTML IDs; literal getElementById references; 9 navigation tabs and 9 sections; ZIP integrity. Full browser/device interaction test is still required on the deployed website.
